package com.gmail.processorcooler;

public interface userInterface {
    public  void update(String theMessage);
}
